﻿#requires -Version 3.0
<#
.SYNOPSIS
  破甲next · Windows 守护校准（wb-guard.ps1）

.DESCRIPTION
  由 pojia-next-mac 的 wb-guard.sh 移植而来。被 Windows 计划任务
  （pojia-next-WorkBuddy-Guard，每 5 分钟）调用：校准云记忆靶点与身份层。
  装载台被移动或删除时安静退出并记一行日志，不空转刷错误。

.NOTES
  UTF-8 with BOM；PowerShell 3.0+ 与 Python 可用即可运行。
#>
param()

$DIR = $PSScriptRoot
if (-not $DIR) { $DIR = Split-Path -Parent $MyInvocation.MyCommand.Path }
$DATA = if ($env:WORKBUDDY_DATA) { $env:WORKBUDDY_DATA } else { Join-Path $env:USERPROFILE ".workbuddy" }
$LOG = Join-Path $DATA "logs\pojia-guard.log"

function Get-Py {
    foreach ($c in @("python", "py", "python3")) {
        try {
            & $c --version 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { return $c }
        } catch {}
    }
    return "python"
}
$PY = Get-Py

function Write-Log([string]$Message) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $LOG) | Out-Null
    Add-Content -Path $LOG -Value $Message -ErrorAction SilentlyContinue
}

# ---- 依赖检查：缺文件就安静退 ----
foreach ($f in @("wb-windows.py", "inject-workbuddy-identity.py", "persona.md")) {
    if (-not (Test-Path (Join-Path $DIR $f))) {
        Write-Log ("{0} [guard] 缺少依赖 {1}，跳过本次校准" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $f)
        exit 0
    }
}

$stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

& $PY (Join-Path $DIR "wb-windows.py") --apply --targets memory > $null 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Log ("{0} [guard] memory 靶点注入失败（exit {1}）" -f $stamp, $LASTEXITCODE)
}

& $PY (Join-Path $DIR "inject-workbuddy-identity.py") --persona (Join-Path $DIR "persona.md") > $null 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Log ("{0} [guard] 身份层注入失败（exit {1}）" -f $stamp, $LASTEXITCODE)
}
