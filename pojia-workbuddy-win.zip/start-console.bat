@echo off
rem ============================================================
rem  pojia-next Windows console launcher (double-click to start)
rem  Keep this file ASCII-only; all Chinese text lives in the .ps1
rem ============================================================
chcp 65001 >nul
cd /d %~dp0
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pojia-console.ps1" menu
if errorlevel 1 (
    echo.
    echo [pojia-next] console exited with an error. See messages above.
    pause
)
