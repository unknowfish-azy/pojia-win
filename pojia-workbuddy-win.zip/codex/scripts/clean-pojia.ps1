﻿#requires -Version 3.0
<#
.SYNOPSIS
  破甲next · 临时文件清理（clean-pojia.ps1）

.DESCRIPTION
  由 pojia-next-mac 的 clean-pojia.sh 移植而来。
  清理 codex 目录下的 .DS_Store / *.tmp / *.log / *.pyc 与 __pycache__；
  -PurgeBackups 额外清理 *.pojia-backup*（codex 与 CODEX_HOME 下，深度 3）。
  默认预览模式；确认执行加 -Yes。

.EXAMPLE
  powershell -File clean-pojia.ps1 -DryRun
  powershell -File clean-pojia.ps1 -Yes
  powershell -File clean-pojia.ps1 -Yes -PurgeBackups
#>
[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$Yes,
    [switch]$PurgeBackups
)

$SCRIPT_DIR = $PSScriptRoot
if (-not $SCRIPT_DIR) { $SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path }
$ROOT = Split-Path -Parent $SCRIPT_DIR
$CODEX_HOME = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE ".codex" }

$targets = New-Object System.Collections.ArrayList

# 文件：.DS_Store / *.tmp / *.log / *.pyc
Get-ChildItem $ROOT -Recurse -File -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -eq ".DS_Store" -or $_.Name -like "*.tmp" -or $_.Name -like "*.log" -or $_.Name -like "*.pyc" } |
    ForEach-Object { [void]$targets.Add($_.FullName) }

# 目录：__pycache__
Get-ChildItem $ROOT -Recurse -Directory -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -eq "__pycache__" } |
    ForEach-Object { [void]$targets.Add($_.FullName) }

if ($PurgeBackups) {
    foreach ($base in @($ROOT, $CODEX_HOME)) {
        if (-not (Test-Path $base)) { continue }
        Get-ChildItem $base -Recurse -File -Force -Depth 3 -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like "*.pojia-backup*" } |
            ForEach-Object { [void]$targets.Add($_.FullName) }
    }
}

if ($targets.Count -eq 0) {
    Write-Host "[*] 没有发现可清理的破甲临时文件。"
    exit 0
}

Write-Host "[*] 将清理以下文件："
foreach ($t in $targets) { Write-Host "  $t" }

if (-not $Yes) {
    Write-Host "[*] 这是预览模式；确认执行请加 -Yes，备份文件需额外加 -PurgeBackups。"
    exit 0
}

$removed = 0
foreach ($t in $targets) {
    try {
        if (Test-Path $t -PathType Container) {
            Remove-Item $t -Recurse -Force
        } else {
            Remove-Item $t -Force
        }
        $removed++
    } catch {
        Write-Host "  [!] 清理失败: $t — $_" -ForegroundColor Yellow
    }
}
Write-Host "[+] 已清理 $removed 个文件。"
