﻿#requires -Version 3.0
<#
.SYNOPSIS
  破甲next · Codex 持久化人格注入（persist-codex.ps1）

.DESCRIPTION
  由 pojia-next-mac 的 persist-codex.sh 移植而来：
  把 persona 部署到 ~/.codex/managed-prompts/pojia-persona.md，
  并把 model_instructions_file 写入 ~/.codex/config.toml（幂等，改前备份）。

.PARAMETER Action
  install    部署 persona + 接线 config.toml
  deep       install + AGENTS.md 人格锚点（双锚点）
  deep-all   全覆盖：config.toml 顶层+profiles / AGENTS.md / instructions.md /
              system-prompt.md / custom-instructions.md / skill-index / persona 副本
  uninstall  还原 config.toml 备份并移除受管 persona 副本
  status     查看注入状态

.PARAMETER CodexHome
  指定 CODEX_HOME，默认 %USERPROFILE%\.codex（或用环境变量 CODEX_HOME）。

.NOTES
  UTF-8 with BOM；PowerShell 3.0+。
#>
[CmdletBinding()]
param(
    [ValidateSet("install", "deep", "deep-all", "uninstall", "status")]
    [string]$Action = "install",
    [string]$CodexHome = ""
)

# 源码带 UTF-8 BOM，PowerShell 5.1 正确读取；输出按控制台代码页转换，不强制改编码。
# 子进程（Python）管道编码跟随控制台，避免 chcp 65001 控制台 + GBK 管道错配花屏。
function Set-PythonPipeEncoding {
    try {
        $name = [Console]::OutputEncoding.WebName
        if ($name -eq "gb2312") { $name = "gb18030" }
        if ($name) { $env:PYTHONIOENCODING = $name }
    } catch {}
}
Set-PythonPipeEncoding

function Get-Py {
    foreach ($c in @("python", "py", "python3")) {
        try {
            & $c --version 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { return $c }
        } catch {}
    }
    return "python"
}
$PY = Get-Py

$SCRIPT_DIR = $PSScriptRoot
if (-not $SCRIPT_DIR) { $SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path }
$PROJECT_ROOT = Split-Path -Parent $SCRIPT_DIR          # <root>\codex
$REPO_ROOT = Split-Path -Parent $PROJECT_ROOT           # <root>

if (-not [string]::IsNullOrWhiteSpace($CodexHome)) {
    $CODEX_HOME = $CodexHome
} elseif ($env:CODEX_HOME) {
    $CODEX_HOME = $env:CODEX_HOME
} else {
    $CODEX_HOME = Join-Path $env:USERPROFILE ".codex"
}

$MANAGED_DIR = Join-Path $CODEX_HOME "managed-prompts"
$CONFIG = Join-Path $CODEX_HOME "config.toml"
$BACKUP = Join-Path $CODEX_HOME "config.toml.pojia-backup"
$MARKER = "# >>> pojia-persona >>>"
$ENDMARKER = "# <<< pojia-persona <<<"

# 人格源探测：脚本位于 <root>\codex\scripts\，向上找一级拿装载台根的 persona.md
$PERSONA_SRC = ""
foreach ($cand in @(
    (Join-Path $REPO_ROOT "persona.md"),
    (Join-Path $PROJECT_ROOT "persona.md"),
    (Join-Path $PROJECT_ROOT "managed-prompts\pojia-persona.md"),
    (Join-Path $REPO_ROOT "managed-prompts\pojia-persona.md")
)) {
    if (Test-Path $cand) { $PERSONA_SRC = $cand; break }
}
if (-not $PERSONA_SRC) { $PERSONA_SRC = Join-Path $REPO_ROOT "persona.md" }
$PERSONA_DST = Join-Path $MANAGED_DIR "pojia-persona.md"

function Test-HasKey {
    if (-not (Test-Path $CONFIG)) { return $false }
    return [bool](Select-String -Path $CONFIG -Pattern '^\s*model_instructions_file\s*=' -Quiet)
}

function Test-IsOurs {
    if (-not (Test-Path $CONFIG)) { return $false }
    return [bool](Select-String -Path $CONFIG -Pattern ([regex]::Escape($MARKER)) -Quiet)
}

function Backup-Config {
    if (-not (Test-Path $BACKUP)) {
        Copy-Item -Path $CONFIG -Destination $BACKUP -Force
    } else {
        Write-Host "[*] existing backup preserved: $BACKUP"
    }
}

function Read-Text([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
}

function Write-Text([string]$Path, [string]$Text) {
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false)))
}

function Install-PersonaCopy {
    if (-not (Test-Path $PERSONA_SRC)) {
        Write-Host "[!] persona source missing: $PERSONA_SRC" -ForegroundColor Red
        exit 1
    }
    New-Item -ItemType Directory -Force -Path $MANAGED_DIR | Out-Null
    if ((Test-Path $PERSONA_DST) -and (Test-SameFile $PERSONA_SRC $PERSONA_DST)) {
        Write-Host "[*] persona already current: $PERSONA_DST"
    } else {
        Copy-Item -Path $PERSONA_SRC -Destination $PERSONA_DST -Force
        Write-Host "[+] persona deployed: $PERSONA_DST"
    }
}

function Test-SameFile([string]$A, [string]$B) {
    if (-not (Test-Path $A) -or -not (Test-Path $B)) { return $false }
    return ((Get-FileHash -Path $A -Algorithm SHA256).Hash -eq (Get-FileHash -Path $B -Algorithm SHA256).Hash)
}

function Sync-SkillIndex {
    $buildIndex = Join-Path $REPO_ROOT "build-index.py"
    if (Test-Path $buildIndex) {
        & $PY $buildIndex $CODEX_HOME | Out-Host
    }
}

function Update-ConfigBlock {
    # 幂等刷新：只替换标记块内容，块外一律不动
    $block = "$MARKER`nmodel_instructions_file = `"$PERSONA_DST`"`n$ENDMARKER"
    $text = Read-Text $CONFIG
    $pattern = [regex]::Escape($MARKER) + '[\s\S]*?' + [regex]::Escape($ENDMARKER)
    $text = [regex]::Replace($text, $pattern, { $block }, 1)
    Write-Text $CONFIG $text
}

function Install-ConfigKey {
    New-Item -ItemType Directory -Force -Path $CODEX_HOME | Out-Null
    if (-not (Test-Path $CONFIG)) {
        Write-Text $CONFIG ""
        Write-Host "[*] created empty config: $CONFIG"
    }
    if (Test-IsOurs) {
        Write-Host "[*] config already has pojia-persona marker; refreshing block only"
        Update-ConfigBlock
        return
    }
    if (Test-HasKey) {
        Write-Host "[!] config.toml already sets model_instructions_file (not ours)." -ForegroundColor Yellow
        Write-Host "    Backing up config and taking over the key (original saved at $BACKUP)."
        Backup-Config
        $text = Read-Text $CONFIG
        $text = [regex]::Replace($text, '(?m)^\s*model_instructions_file\s*=.*$\n?', '')
        $block = "$MARKER`nmodel_instructions_file = `"$PERSONA_DST`"`n$ENDMARKER"
        Write-Text $CONFIG ($block + "`n" + $text.TrimStart("`n"))
        Write-Host "[+] took over model_instructions_file in $CONFIG (backup: $BACKUP)"
        return
    }
    Backup-Config
    $block = "$MARKER`nmodel_instructions_file = `"$PERSONA_DST`"`n$ENDMARKER"
    $text = Read-Text $CONFIG
    if ($text.Length -gt 0 -and -not $text.EndsWith("`n")) { $text += "`n" }
    Write-Text $CONFIG ($text + $block + "`n")
    Write-Host "[+] injected model_instructions_file into $CONFIG (backup: $BACKUP)"
}

function Invoke-Install {
    Install-PersonaCopy
    Sync-SkillIndex
    Install-ConfigKey
    Write-Host "[+] Codex persistent injection complete. Restart Codex to load the persona."
}

function Invoke-InstallInner {
    Install-PersonaCopy
    Sync-SkillIndex
}

function Invoke-Deep {
    Invoke-Install
    $agents = Join-Path $CODEX_HOME "AGENTS.md"
    if (Test-Path $agents) {
        if (-not (Test-Path "$agents.pojia-backup")) {
            Copy-Item -Path $agents -Destination "$agents.pojia-backup" -Force
        } else {
            Write-Host "[*] existing backup preserved: $agents.pojia-backup"
        }
    }
    & $PY (Join-Path $SCRIPT_DIR "inject-agents.py") $agents $PERSONA_DST install
    Write-Host "[+] Deep injection complete: model_instructions_file + AGENTS.md double-anchored."
}

function Invoke-DeepAll {
    # 1) persona + skill index（同 install）
    Invoke-InstallInner

    # 2) config.toml 全量注入（顶层 + 每个 profile）
    New-Item -ItemType Directory -Force -Path $CODEX_HOME | Out-Null
    if (-not (Test-Path $CONFIG)) { Write-Text $CONFIG "" }
    if (-not (Test-Path $BACKUP)) { Copy-Item -Path $CONFIG -Destination $BACKUP -Force }
    & $PY (Join-Path $SCRIPT_DIR "inject-config.py") $CONFIG $PERSONA_DST install

    # 3) AGENTS.md 顶部锚点
    $agents = Join-Path $CODEX_HOME "AGENTS.md"
    if (Test-Path $agents) { Copy-Item -Path $agents -Destination "$agents.pojia-backup" -Force -ErrorAction SilentlyContinue }
    & $PY (Join-Path $SCRIPT_DIR "inject-agents.py") $agents $PERSONA_DST install

    # 4) 老版本/其它版本口子：instructions.md / system-prompt.md / custom-instructions.md
    foreach ($f in @("instructions.md", "system-prompt.md", "custom-instructions.md")) {
        $tgt = Join-Path $CODEX_HOME $f
        if (Test-Path $tgt) { Copy-Item -Path $tgt -Destination "$tgt.pojia-backup" -Force }
        Copy-Item -Path $PERSONA_DST -Destination $tgt -Force
        Write-Host "[+] persona written: $tgt"
    }

    Write-Host ""
    Write-Host "=============================================="
    Write-Host "  FULL COVERAGE INJECTION COMPLETE"
    Write-Host "=============================================="
    Write-Host "Covered surfaces:"
    Write-Host "  1. config.toml (top-level + all profiles)"
    Write-Host "  2. AGENTS.md (top anchor)"
    Write-Host "  3. instructions.md (legacy global)"
    Write-Host "  4. system-prompt.md (if supported)"
    Write-Host "  5. custom-instructions.md (if supported)"
    Write-Host "  6. skill-index.json (auto skill routing)"
    Write-Host "  7. managed-prompts/pojia-persona.md (source of truth)"
    Write-Host ""
    Write-Host "Restart Codex completely to load."
}

function Invoke-Uninstall {
    if (Test-IsOurs) {
        $text = Read-Text $CONFIG
        $pattern = [regex]::Escape($MARKER) + '[\s\S]*?' + [regex]::Escape($ENDMARKER) + '\n?'
        $text = [regex]::Replace($text, $pattern, '', 1)
        Write-Text $CONFIG $text
        Write-Host "[+] removed pojia block from $CONFIG"
    } else {
        Write-Host "[*] no pojia block found in $CONFIG"
    }
    if ((Test-Path $BACKUP) -and (Test-HasKey) -and (-not (Test-IsOurs))) {
        Copy-Item -Path $BACKUP -Destination $CONFIG -Force
        Write-Host "[+] restored original config from $BACKUP"
    }
    if (Test-Path $PERSONA_DST) {
        Remove-Item $PERSONA_DST -Force
        Write-Host "[+] removed $PERSONA_DST"
    }
    $idx = Join-Path $CODEX_HOME "skill-index.json"
    if (Test-Path $idx) {
        Remove-Item $idx -Force
        Write-Host "[+] removed $idx"
    }
    $agents = Join-Path $CODEX_HOME "AGENTS.md"
    if (Test-Path $agents) {
        & $PY (Join-Path $SCRIPT_DIR "inject-agents.py") $agents $PERSONA_DST remove
    }
    Write-Host "[+] Codex persistent injection removed."
}

function Show-StatusInfo {
    Write-Host "Codex home : $CODEX_HOME"
    Write-Host ("config     : {0} ({1})" -f $CONFIG, $(if (Test-Path $CONFIG) { "exists" } else { "missing" }))
    if (Test-IsOurs) {
        Write-Host "persona    : ACTIVE (pojia block present)"
        Select-String -Path $CONFIG -Pattern ([regex]::Escape($MARKER)) -Context 0, 2 | ForEach-Object { $_.Line; $_.Context.PostContext }
    } elseif (Test-HasKey) {
        Write-Host "persona    : model_instructions_file set by something else"
    } else {
        Write-Host "persona    : NOT injected"
    }
    if (Test-Path $PERSONA_DST) { Write-Host "managed    : $PERSONA_DST exists" } else { Write-Host "managed    : persona copy missing" }
    $agents = Join-Path $CODEX_HOME "AGENTS.md"
    if ((Test-Path $agents) -and (Select-String -Path $agents -Pattern ">>> pojia-persona >>>" -Quiet)) {
        Write-Host "agents.md  : persona anchor ACTIVE"
    } else {
        Write-Host "agents.md  : no anchor (run deep for double injection)"
    }
}

switch ($Action) {
    "install" { Invoke-Install }
    "deep" { Invoke-Deep }
    "deep-all" { Invoke-DeepAll }
    "uninstall" { Invoke-Uninstall }
    "status" { Show-StatusInfo }
}
