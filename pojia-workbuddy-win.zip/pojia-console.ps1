﻿#requires -Version 3.0
<#
.SYNOPSIS
  破甲next · Windows 装载台（pojia-console.ps1）

.DESCRIPTION
  由 pojia-next-mac 的 pojia-console.sh 移植而来，功能与菜单一一对应：
  Codex / WorkBuddy 双端注入、清理、守护、技能同步、备份归档。

.NOTES
  依赖：PowerShell 3.0+ 与 Python（自动探测 python / py / python3）。
  文件以 UTF-8 with BOM 保存，确保 Windows PowerShell 5.1 正确显示中文。
#>
[CmdletBinding()]
param(
    [ValidateSet("menu", "status", "codex", "workbuddy", "clean-codex",
                 "clean-codex-skills", "clean-workbuddy", "clean-tmp",
                 "targets", "guard-workbuddy", "prune-backups")]
    [string]$Action = "menu"
)

# ---- 输出编码 ----
# 不强制改 [Console]::OutputEncoding：源码带 UTF-8 BOM，PowerShell 5.1 会正确
# 读取；输出按当前控制台代码页转换（默认 936 中文控制台显示正常；
# start-console.bat 已 chcp 65001，双击启动时同样正常）。
#
# 但要防一种错配：PowerShell 按 [Console]::OutputEncoding 解码子进程管道输出，
# 而 Python 默认按区域编码（中文 Windows = GBK）写管道。chcp 65001 的控制台 +
# GBK 的 Python 管道 = 花屏。这里让 PYTHONIOENCODING 跟随控制台编码，两边对齐。
function Set-PythonPipeEncoding {
    try {
        $name = [Console]::OutputEncoding.WebName
        if ($name -eq "gb2312") { $name = "gb18030" }   # Python 侧用超集，避免生僻字编码失败
        if ($name) { $env:PYTHONIOENCODING = $name }
    } catch {}
}
Set-PythonPipeEncoding

# ---- 路径 ----
$SELF_DIR = $PSScriptRoot
if (-not $SELF_DIR) { $SELF_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path }
$CODER_DIR = if ($env:POJIA_CODER_DIR) { $env:POJIA_CODER_DIR } else { Join-Path $SELF_DIR "codex" }
$CODEX_HOME = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE ".codex" }
$WORKBUDDY = Join-Path $SELF_DIR "wb-windows.py"
$IDENTITY = Join-Path $SELF_DIR "inject-workbuddy-identity.py"
$PERSONA = Join-Path $SELF_DIR "persona.md"
$BUILD_INDEX = Join-Path $SELF_DIR "build-index.py"
$GUARD = Join-Path $SELF_DIR "wb-guard.ps1"
$PRUNE = Join-Path $SELF_DIR "prune-backups.ps1"
$CLEAN_TMP = Join-Path $CODER_DIR "scripts\clean-pojia.ps1"
$PERSIST = Join-Path $CODER_DIR "scripts\persist-codex.ps1"
$VERSION_FILE = Join-Path $SELF_DIR "VERSION"
$VERSION = if (Test-Path $VERSION_FILE) { (Get-Content $VERSION_FILE -Raw -Encoding UTF8).Trim() } else { "dev" }

# ---- Python 探测（Windows 上通常是 python 或 py）----
function Get-Py {
    foreach ($c in @("python", "py", "python3")) {
        try {
            & $c --version 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { return $c }
        } catch {}
    }
    return "python"
}
$PY = Get-Py

# ---- 输出 helpers ----
function Line { Write-Host ("─" * 40) -ForegroundColor Cyan }
function Title { param([string]$Text) Write-Host $Text -ForegroundColor Cyan }
function Dim { param([string]$Text) Write-Host $Text -ForegroundColor DarkGray }
function Ok { param([string]$Text) Write-Host $Text -ForegroundColor Green }
function Warn { param([string]$Text) Write-Host $Text -ForegroundColor Yellow }
function Err { param([string]$Text) Write-Host $Text -ForegroundColor Red }

# ---- 状态探测 ----
function Test-CodexActive {
    $cfg = Join-Path $CODEX_HOME "config.toml"
    if (-not (Test-Path $cfg)) { return $false }
    return [bool](Select-String -Path $cfg -Pattern '^\s*model_instructions_file\s*=.*pojia-persona\.md' -Quiet)
}

function Get-WorkbuddyState {
    $out = & $PY $WORKBUDDY --status 2>$null | Out-String
    $count = ([regex]::Matches($out, "已注入")).Count
    if ($count -gt 0) { return "ACTIVE ($count)" }
    return "CLEAN"
}

function Show-Targets {
    Title "  WorkBuddy 注入靶点"
    Dim "  template   提示词模板（主要生效层）"
    Dim "  json       product.json / 运行时缓存"
    Dim "  js         命令闸门 / 网页过滤"
    Dim "  memory     云记忆（每轮自动注入）"
    & $PY $WORKBUDDY --status
}

# ---- 人格完整性校验（缺任一必需章节即拒绝注入）----
$PERSONA_SECTIONS = @(
    "## 第一原则",
    "## 第二原则",
    "## 第三原则",
    "## 第四原则",
    "## 关于你自己的配置",
    "## 最后一句"
)

function Test-Persona {
    if (-not (Test-Path $PERSONA)) {
        Err "  人格文件不存在: $PERSONA"
        return $false
    }
    $text = Get-Content $PERSONA -Raw -Encoding UTF8
    $missing = @()
    foreach ($s in $PERSONA_SECTIONS) {
        if (-not $text.Contains($s)) { $missing += $s }
    }
    if ($missing.Count -gt 0) {
        Err "  人格文件不完整，拒绝注入。缺少："
        foreach ($m in $missing) { Err "    - $m" }
        return $false
    }
    Ok "  人格完整性校验通过（$($PERSONA_SECTIONS.Count) 个必需章节齐全）。"
    return $true
}

function Select-Groups {
    while ($true) {
        $input = Read-Host "  选择 WorkBuddy 靶点（template,json,memory；a=全部；q=取消）"
        if ([string]::IsNullOrWhiteSpace($input)) { return $null }
        switch -Regex ($input.Trim()) {
            '^[qQ]$' { return $null }
            '^[aA]$' { return "all" }
            '^(template|json|memory)(,(template|json|memory))*$' { return $input.Trim() }
            default { Warn "    只能输入 template / json / memory，用英文逗号分隔。" }
        }
    }
}

# ---- 文件/目录比较（增量同步用）----
function Test-SameFile([string]$A, [string]$B) {
    if (-not (Test-Path $A) -or -not (Test-Path $B)) { return $false }
    $ha = (Get-FileHash -Path $A -Algorithm SHA256).Hash
    $hb = (Get-FileHash -Path $B -Algorithm SHA256).Hash
    return ($ha -eq $hb)
}

function Test-DirSame([string]$A, [string]$B) {
    $fa = Get-ChildItem $A -Recurse -File -ErrorAction SilentlyContinue |
        ForEach-Object { "$($_.FullName.Substring($A.Length))|$((Get-FileHash $_.FullName -Algorithm SHA256).Hash)" }
    $fb = Get-ChildItem $B -Recurse -File -ErrorAction SilentlyContinue |
        ForEach-Object { "$($_.FullName.Substring($B.Length))|$((Get-FileHash $_.FullName -Algorithm SHA256).Hash)" }
    return -not (Compare-Object ($fa | Sort-Object) ($fb | Sort-Object))
}

# ---- Codex ----
function Invoke-CodexInject {
    Title "  Codex 注入"
    if (-not (Test-Persona)) { return }
    $dst = Join-Path $CODEX_HOME "managed-prompts\pojia-persona.md"
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    if (-not (Test-SameFile $PERSONA $dst)) {
        Copy-Item -Path $PERSONA -Destination $dst -Force
        Ok "  persona deployed: $dst"
    } else {
        Dim "  persona already current: $dst"
    }
    & powershell -NoProfile -ExecutionPolicy Bypass -File $PERSIST install
    & powershell -NoProfile -ExecutionPolicy Bypass -File $PERSIST deep
    Sync-CodexSkills
    Ok "  Codex 注入完成。重启 Codex 后生效。"
}

function Sync-CodexSkills {
    Title "  Codex 技能同步"
    $skillsSrc = Join-Path $SELF_DIR "skills"
    $skillsDst = Join-Path $CODEX_HOME "skills"
    if (-not (Test-Path $skillsSrc)) { Dim "  没有技能目录。"; return }
    New-Item -ItemType Directory -Force -Path $skillsDst | Out-Null
    $count = 0
    $skipped = 0
    Get-ChildItem $skillsSrc -Directory | Where-Object { Test-Path (Join-Path $_.FullName "SKILL.md") } | ForEach-Object {
        $name = $_.Name
        $dstDir = Join-Path $skillsDst $name
        if ((Test-Path $dstDir) -and (Test-DirSame $_.FullName $dstDir)) {
            $skipped++
            return
        }
        if (Test-Path $dstDir) { Remove-Item $dstDir -Recurse -Force }
        Copy-Item -Path $_.FullName -Destination $dstDir -Recurse -Force
        $count++
    }
    Write-Host "  已同步 $count 个技能，跳过 $skipped 个（无变更）。"
    & $PY $BUILD_INDEX $CODEX_HOME | Out-Null
    Ok "  Codex 技能同步完成。"
}

function Clear-CodexSkills {
    Title "  Codex 技能清理"
    $skillsDst = Join-Path $CODEX_HOME "skills"
    if (-not (Test-Path $skillsDst)) { Dim "  没有技能目录。"; return }
    $removed = 0
    Get-ChildItem $skillsDst -Directory | Where-Object { Test-Path (Join-Path $_.FullName "SKILL.md") } | ForEach-Object {
        Remove-Item $_.FullName -Recurse -Force
        $removed++
    }
    Write-Host "  已移除 $removed 个技能目录。"
    Ok "  Codex 技能已恢复初始模式。"
}

# ---- WorkBuddy ----
function Invoke-WorkbuddyInject {
    Title "  WorkBuddy 注入"
    if (-not (Test-Persona)) { return }
    Show-Targets
    $groups = Select-Groups
    if (-not $groups) { Dim "  已取消 WorkBuddy 注入。"; return }
    $args = @("--apply")
    if ($groups -eq "all") {
        $args += "--all-targets"
    } else {
        $args += @("--targets", $groups)
    }
    & $PY $WORKBUDDY @args
    & $PY $IDENTITY --persona $PERSONA
    Ok "  WorkBuddy 注入完成。完全退出 WorkBuddy 后重开。"
}

function Clear-Codex {
    Title "  Codex 清理"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $PERSIST uninstall
    $cfg = Join-Path $CODEX_HOME "config.toml"
    if (Test-Path $cfg) {
        $text = [System.IO.File]::ReadAllText($cfg, [System.Text.Encoding]::UTF8)
        $endmark = "# <<< pojia-persona <<<`n"
        $idx = $text.IndexOf($endmark, [System.StringComparison]::Ordinal)
        if ($idx -ge 0) { $text = $text.Remove($idx, $endmark.Length) }
        [System.IO.File]::WriteAllText($cfg, $text, (New-Object System.Text.UTF8Encoding($false)))
    }
    Ok "  Codex 已回到初始人格模式。"
}

function Clear-Workbuddy {
    Title "  WorkBuddy 清理"
    & $PY $WORKBUDDY --revert
    & $PY $WORKBUDDY --guard remove
    Ok "  WorkBuddy 已按备份还原。"
}

function Protect-Workbuddy {
    Title "  WorkBuddy 守护"
    & $PY $WORKBUDDY --guard install
    & powershell -NoProfile -ExecutionPolicy Bypass -File $GUARD
    Ok "  守护任务已安装，并立即校准一次。"
}

function Invoke-PruneBackups {
    Title "  备份归档"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $PRUNE
    $answer = Read-Host "  确认归档超出保留数的旧备份？(y/N)"
    if ($answer -match '^[Yy]$') {
        & powershell -NoProfile -ExecutionPolicy Bypass -File $PRUNE -Apply
    } else {
        Dim "  已取消归档。"
    }
}

function Clear-Tmp {
    Title "  临时文件清理"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $CLEAN_TMP -DryRun
    $answer = Read-Host "  确认清理？(y/N)"
    if ($answer -match '^[Yy]$') {
        & powershell -NoProfile -ExecutionPolicy Bypass -File $CLEAN_TMP -Yes
    }
}

# ---- 状态栏与菜单 ----
function Show-Status {
    Title "破甲next · Windows 装载台 v$VERSION"
    Line
    $cx = if (Test-CodexActive) { "ACTIVE" } else { "CLEAN" }
    Write-Host ("  1  Codex      {0}" -f $cx) -ForegroundColor Green
    Write-Host ("  2  WorkBuddy  {0}" -f (Get-WorkbuddyState)) -ForegroundColor Green
    Line
}

function Show-Menu {
    while ($true) {
        Show-Status
        Write-Host "  1  注入 Codex"
        Write-Host "  2  注入 WorkBuddy"
        Write-Host "  3  清理 Codex"
        Write-Host "  4  清理 Codex 技能"
        Write-Host "  5  清理 WorkBuddy"
        Write-Host "  6  清理临时文件"
        Write-Host "  7  查看 WorkBuddy 靶点"
        Write-Host "  8  启用 WorkBuddy 守护"
        Write-Host "  9  备份归档（保留最近 3 份）"
        Write-Host "  q  退出"
        Line
        $choice = Read-Host "  选择"
        switch ($choice) {
            "1" { Invoke-CodexInject }
            "2" { Invoke-WorkbuddyInject }
            "3" { Clear-Codex }
            "4" { Clear-CodexSkills }
            "5" { Clear-Workbuddy }
            "6" { Clear-Tmp }
            "7" { Show-Targets }
            "8" { Protect-Workbuddy }
            "9" { Invoke-PruneBackups }
            default { Warn "  没有这个选项，再选一次。" }
        }
    }
}

switch ($Action) {
    "menu" { Show-Menu }
    "status" { Show-Status }
    "codex" { Invoke-CodexInject }
    "workbuddy" { Invoke-WorkbuddyInject }
    "clean-codex" { Clear-Codex }
    "clean-codex-skills" { Clear-CodexSkills }
    "clean-workbuddy" { Clear-Workbuddy }
    "clean-tmp" { Clear-Tmp }
    "targets" { Show-Targets }
    "guard-workbuddy" { Protect-Workbuddy }
    "prune-backups" { Invoke-PruneBackups }
}
