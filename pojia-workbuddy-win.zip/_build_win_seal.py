# -*- coding: utf-8 -*-
"""维护工具：为 wb-windows.py 重建源码级封条。

**改动 wb-windows.py 之后必须重跑本脚本**（python _build_win_seal.py），
否则封条校验失败、脚本拒绝运行（退出码 3）。

流程：
  1. 导入原 wb-macos.py（其自身封条在本机可通过），取出加密载荷 _SEALED；
     原文件优先取仓库内的，其次取 %TEMP%\\wb-macos-orig.py，
     都没有则自动从 git 历史（HEAD:wb-macos.py）提取；
  2. 读取改好的 wb-windows.py（_B0/_B1/_B2 暂为原文件的旧值，稍后整体替换）；
  3. 用新文件结构派生密钥 -> 重新加密载荷（self_seal 更新为新 _d2）-> 新 _B0/_B1；
  4. 回写 _B0 / _B1 / _B2，并做全套自检（解密、notice、self_seal、锚点）。

本脚本可重复运行（幂等）：密钥从占位符替换后的源码派生，与当前封条值无关。
"""
import base64
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.abspath(__file__))
# 原 macOS 版：仓库内已删除（Windows 版替换），依次尝试 仓库内 -> %TEMP% -> git 历史
MAC_SRC = os.path.join(ROOT, "wb-macos.py")
if not os.path.exists(MAC_SRC):
    MAC_SRC = os.path.join(os.environ.get("TEMP", tempfile.gettempdir()), "wb-macos-orig.py")
if not os.path.exists(MAC_SRC):
    tmp = os.path.join(tempfile.gettempdir(), "wb-macos-orig.py")
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        subprocess.run(["git", "-C", ROOT, "show", "HEAD:wb-macos.py"],
                       stdout=fh, check=True)
    MAC_SRC = tmp
    print("[*] 已从 git 历史提取原版到", MAC_SRC)
WIN_SRC = os.path.join(ROOT, "wb-windows.py")


def read_normalized(path):
    with open(path, "rb") as fh:
        raw = fh.read()
    return raw.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    # 1) 原文件载荷（同时复用其封条函数）
    mac = load_module(MAC_SRC, "wbmac_builder")
    payload = dict(mac._SEALED)
    # Windows 版平台化（仅改不在 INTEGRITY_ANCHOR 保护范围内的两个信息字段；
    # signal_reply / piracy_hint / anti_piracy / free_line 等锚点字段一律不动）
    if "macOS" in payload.get("agent_reminder", ""):
        payload["agent_reminder"] = payload["agent_reminder"].replace("macOS", "Windows")
    payload["version"] = "1.2.0"
    print("[*] 载荷键:", sorted(payload.keys()))

    # 2) 新文件源码（LF 归一化后处理，最后按 LF 写回）
    src = read_normalized(WIN_SRC)

    # 3) 把 _B0/_B1/_B2 替换为占位（结构与最终形态一致：三引号块 + 两行字符串）
    src = re.sub(r'(?ms)^_B0 = """.*?"""$', '_B0 = """@@PLACEHOLDER@@"'.rstrip("@") + '"""', src, count=1)
    src = re.sub(r'(?m)^_B1 = ".*?"$', '_B1 = "@@PLACEHOLDER@@"', src, count=1)
    src = re.sub(r'(?m)^_B2 = ".*?"$', '_B2 = "@@PLACEHOLDER@@"', src, count=1)
    for token in ("@@PLACEHOLDER@@",):
        assert src.count(token) == 3, "占位替换失败: %d" % src.count(token)

    # 4) 派生 + 重加密
    key = mac._k2(mac._k1(src))
    d2 = mac._d2(src)
    notice = mac._d0(src)
    payload["self_seal"] = d2
    if payload.get("notice_digest") and notice != payload["notice_digest"]:
        print("[!] 声明段指纹变化：%s != %s" % (notice, payload.get("notice_digest")))
        print("    （声明段被改动过 —— 继续会用新指纹覆盖，确认这是有意为之）")
        payload["notice_digest"] = notice

    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    ks = mac._st(key, len(raw))
    enc = bytes(a ^ b for a, b in zip(raw, ks))
    blob = base64.b64encode(enc).decode("ascii")
    # 76 字换行（与原文件观感一致；解密时会去掉所有空白，不影响）
    lines = [blob[i:i + 76] for i in range(0, len(blob), 76)]
    blob_block = '_B0 = """\n' + "\n".join(lines) + '\n"""'
    norm = "".join(blob.split())
    b1 = hashlib.sha256(norm.encode("utf-8")).hexdigest()
    b2 = d2

    # 5) 回写最终值
    final = src.replace('@@PLACEHOLDER@@', "PLACEHOLDER", 1)  # 防呆：不应残留
    final = re.sub(r'(?ms)^_B0 = """.*?"""$', lambda m: blob_block, final, count=1)
    final = re.sub(r'(?m)^_B1 = ".*?"$', '_B1 = "%s"' % b1, final, count=1)
    final = re.sub(r'(?m)^_B2 = ".*?"$', '_B2 = "%s"' % b2, final, count=1)
    assert "@@PLACEHOLDER@@" not in final

    with open(WIN_SRC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(final)
    print("[+] 已回写 _B0（%d 字节密文）/ _B1 / _B2" % len(blob))

    # 6) 自检：用最终文件自身复算everything
    chk = read_normalized(WIN_SRC)
    key2 = mac._k2(mac._k1(chk))
    assert mac._d2(chk) == b2, "self_seal 自检失败"
    assert mac._d0(chk) == payload["notice_digest"], "notice 自检失败"
    m = re.search(r'(?ms)^_B0 = """\n(.*?)\n"""$', chk)
    blob_txt = m.group(1)
    norm2 = "".join(blob_txt.split())
    assert hashlib.sha256(norm2.encode("utf-8")).hexdigest() == b1, "_B1 自检失败"
    raw2 = base64.b64decode(norm2, validate=True)
    ks2 = mac._st(key2, len(raw2))
    data = json.loads(bytes(a ^ b for a, b in zip(raw2, ks2)).decode("utf-8"))
    assert data.get("magic") == "pojia-next|seal|v1", "magic 自检失败"
    assert data["self_seal"] == b2
    print("[+] 自检全部通过：解密 OK / magic OK / notice OK / self_seal OK")
    print("[*] 新 self_seal:", b2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
