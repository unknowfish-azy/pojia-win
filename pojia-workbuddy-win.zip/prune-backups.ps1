﻿#requires -Version 3.0
<#
.SYNOPSIS
  破甲next · Windows 备份保留策略（prune-backups.ps1）

.DESCRIPTION
  由 pojia-next-mac 的 prune-backups.sh 移植而来。
  备份目录只增长；按修改时间保留最近 N 份，其余移到 _archive\<时间戳>\（不删除，可回滚）。

.PARAMETER Apply
  真正执行归档；不加则只预演（列出将归档的旧备份，不动作）。

.PARAMETER Keep
  保留最近几份，默认 3。

.PARAMETER BackupRoot
  指定备份根目录，默认 %USERPROFILE%\Desktop\pojia-next-windows\pojia-backups。

.EXAMPLE
  powershell -File prune-backups.ps1            # 预演
  powershell -File prune-backups.ps1 -Apply     # 归档
  powershell -File prune-backups.ps1 -Keep 5    # 保留最近 5 份
#>
[CmdletBinding()]
param(
    [switch]$Apply,
    [int]$Keep = 3,
    [string]$BackupRoot = ""
)

if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $BackupRoot = Join-Path $env:USERPROFILE "Desktop\pojia-next-windows\pojia-backups"
}

if (-not (Test-Path $BackupRoot)) {
    Write-Host "[*] 备份目录不存在: $BackupRoot（无需清理）"
    exit 0
}

# 只清理带时间戳的备份目录，不动固定名称的（WorkBuddy / _archive）
$dirs = Get-ChildItem $BackupRoot -Directory |
    Where-Object { $_.Name -ne "_archive" -and $_.Name -ne "WorkBuddy" } |
    Sort-Object LastWriteTime -Descending

$total = @($dirs).Count
if ($total -le $Keep) {
    Write-Host "[*] 备份 $total 份，未超过保留数 $Keep，无需清理。"
    exit 0
}

Write-Host "备份目录: $BackupRoot"
Write-Host "共 $total 份，保留最近 $Keep 份。"
Write-Host ""
Write-Host "保留:"
$i = 0
foreach ($d in $dirs) {
    $i++
    if ($i -le $Keep) { Write-Host "  [keep] $($d.Name)" }
}
Write-Host ""
Write-Host "将归档:"

if ($Apply) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $archive = Join-Path $BackupRoot "_archive\$stamp"
    New-Item -ItemType Directory -Force -Path $archive | Out-Null
}

$i = 0
$moved = 0
foreach ($d in $dirs) {
    $i++
    if ($i -le $Keep) { continue }
    Write-Host "  [old ] $($d.Name)"
    if ($Apply) {
        try {
            Move-Item -Path $d.FullName -Destination $archive -Force
            $moved++
        } catch {
            Write-Host "    [!] 归档失败: $($d.Name) — $_"
        }
    }
}

if ($Apply) {
    Write-Host ""
    Write-Host "[+] 已归档 $moved 份 → $archive"
    Write-Host "    归档内容不会被自动删除，确认无用后可自行清理。"
} else {
    Write-Host ""
    Write-Host "[*] 预演结束，未改动任何文件。加 -Apply 执行归档。"
}
