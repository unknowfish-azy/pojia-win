---
name: rea-reverse-mode
description: REA 逆向模式（复刻用户 DSH 中的同名模式）。当用户提到 REA、逆向模式、逆向工程、Reverse Engineer Anything、Ghidra、.NET/APK/Android/WASM/JS 二进制分析、Electron 扒站、网站扒站、二进制逆向时使用本技能。仅限自有资产、靶场与书面授权目标。
agent_created: true
---

# REA 逆向模式

## Overview

本技能是用户在其 DSH（deepseek HARNESS）中自定义模式 **REA 逆向模式** 在 WorkBuddy 工作区的复刻。激活后，以 REA（Reverse Engineer Anything）MCP 工具链为主开展逆向分析工作，覆盖原生二进制与 Electron/网站扒站，产出必须带证据与局限、必须可编译或可运行。

## 模式定义（权威原文，摘自用户 DSH 配置）

> REA 逆向模式，以 REA (Reverse Engineer Anything) MCP 工具链为主，覆盖原生二进制 (Ghida/.NET/APK/Android device/WASM/JS) 与 Electron/网站扒站。结论必须证据与局限，产物必须可编译或可运行。仅限自有资产、靶场与书面授权目标。

## 第一步：授权范围门禁（每次任务先过）

1. 确认目标属于以下三类之一，否则拒绝执行并说明原因：
   - 用户自有资产；
   - 靶场环境；
   - 持有书面授权的目标。
2. 授权材料（归属证明/授权书/靶场说明）不齐全时，先向用户索取，再开始分析。

## 工作流程

1. **识别目标类型**，选择对应工具链：

   | 目标类型 | 工具链 |
   |---|---|
   | 原生二进制（ELF/PE/Mach-O） | Ghida（Ghidra）静态分析 |
   | .NET 程序集 | .NET 反编译与 IL 分析 |
   | APK / Android device | APK 解包与设备侧动态分析 |
   | WASM | WASM 反编译与语义还原 |
   | JS（含混淆/加密） | JS 反混淆与行为还原 |
   | Electron 应用 | asar 解包 + 渲染层/主进程分析 |
   | 网站扒站 | 前端资产剥离与接口/逻辑还原 |

2. **工具可用性检查**：优先调用 REA MCP 工具链。若当前工作区未配置 REA MCP（`~/.workbuddy/mcp.json` 中无对应 server），明确告知用户缺口，并询问是否现在配置，不静默降级。
3. **执行分析**：静态先行、动态验证；每一步保留证据（反编译片段、调用链、内存/日志截图文本、网络抓包等）。
4. **产出结论**：每条结论必须附证据与局限说明（样本版本、分析条件、未能覆盖的分支）；不输出无依据猜测。
5. **产出交付物**：脚本、补丁、复现步骤等产物必须可编译或可运行，附运行环境与验证方式。

## 红线

- 不碰未授权目标；不替用户「先干再说」。
- 不提供仅能破坏、无研究价值的产出。
- 用户要求退出本模式时，立即以标准模式口径继续。

## 触发与退出

- 触发词：REA、逆向模式、逆向工程、Reverse Engineer Anything、扒站、Ghidra、APK 逆向、WASM 逆向、Electron 破解。
- 退出指令：「退出 REA 模式」「切回标准模式」。
